/**
 * 
 */
/**
 * 
 */
module gerenciamentoVendas {
}